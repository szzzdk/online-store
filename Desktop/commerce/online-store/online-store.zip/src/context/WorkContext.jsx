// import React, { createContext, useContext } from 'react'
// import { works } from "../data/works" 

// const WorkContext = createContext();

// export function useWorks() {
//     return useContext(WorkContext);
// }

// export function WorkProvider({ children }) {
//     return (
//         <WorkContext.Provider value={works}>{ children }</WorkContext.Provider>
//     )
// }

