import React, {useState} from 'react'
import './ContactForm.css'

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    phoneNumber: '',
    contactMethod: '',
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:4345/api/user', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        // Обработка успешной регистрации
        console.log('Мы свяжемся с вами в ближайшее время');
      } else {
        // Обработка ошибок сервера
        console.error('Ошибка при отправки заявки');
      }
    } catch (error) {
      // Обработка ошибок сети
      console.error('Ошибка сети');
    }
  };

  return (
    <div className='form__container'>
        <div className='left-side'>
            <h1 className='form__title'>
                Давайте начнем разработку вашего сайта уже сегодня
            </h1>
        </div>
        <div className='right-side'>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Ваше имя"
            value={formData.name}
            onChange={handleChange}
            required
          />
          <input
            type="tel"
            name="phoneNumber"
            placeholder="Ваш номер телефона"
            value={formData.phoneNumber}
            onChange={handleChange}

          />
          <select
            name="contactMethod"
            value={formData.contactMethod}
            onChange={handleChange}
            required  
          >
            <option value="">Выберите способ связи</option>
            <option value="Email">Email</option>
            <option value="WhatsApp">WhatsApp</option>
            <option value="Telegram">Telegram</option>
          </select>
          <button type="submit">Отправить</button>
        </form>
        </div>
    </div>
  )
}

export default ContactForm;