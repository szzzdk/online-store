import React from "react";
import ListGroup from "react-bootstrap/ListGroup";
import "./ListServices.css";
import Number01 from "../../assets/number01.svg";
import Number02 from "../../assets/number02.svg";
import Number03 from "../../assets/number03.svg";
import Number04 from "../../assets/number04.svg";

const ListServices = () => {
    return (
        <div className="services__main__container">
            <ListGroup className="services__container">
                <ListGroup.Item className="bootstr__item1">
                    <div className="item__services">
                        <p className="services__title">Услуги</p>
                        <button className="services__btn1">
                            Ничего не понятно, хочу просто сайт
                        </button>
                    </div>
                </ListGroup.Item>
                <ListGroup.Item
                    className="bootstr__item"
                    style={{
                        backgroundColor: '#282929',
                        border: '1px solid #282929',
                    }}
                >
                    <div className="item__service4">
                        <div className="item item1">
                            <img
                                src={Number01}
                                alt="number01"
                                width="40"
                                height="40"
                                className="service__img"
                            />
                            <p className="service__title">Лендинг</p>
                        </div>
                        <div className="service__details">
                            <span className="service__price price1">
                                от 150000 тенге 
                            </span>
                            <button className="services__btn2 btn2">
                                Подробнее
                            </button>
                        </div>
                    </div>
                    <div>
                        <span className="service__description">
                            Одностраничный сайт для сбора контактов от посетителей или продажи товара/услуги
                        </span>
                    </div>
                </ListGroup.Item>
                <ListGroup.Item
                    className="bootstr__item"
                    style={{
                        backgroundColor: '#3a3b3b',
                        border: '1px solid #3a3b3b',
                    }}
                >
                    <div className="item__service2">
                        <div className="item item2">
                            <img
                                src={Number02}
                                alt="number02"
                                width="40"
                                height="40"     
                                className="service__img"
                            />
                            <p className="service__title">Многостраничник</p>
                        </div>
                        <div className="service__details">
                            <span className="service__price price2">
                                от 250000 тенге
                            </span>
                            <button className="services__btn2 btn2">
                                Подробнее
                            </button>
                        </div>
                    </div>
                    <div>
                        <span className="service__description">
                            Классический сайт, навигация по которому осуществляется с помощью меню
                        </span>
                    </div>
                </ListGroup.Item>
                <ListGroup.Item
                    className="bootstr__item"
                    style={{
                        backgroundColor: '#3a3b3b',
                        border: '1px solid #3a3b3b',
                    }}
                >
                    <div className="item__service3">
                        <div className="item item3">
                            <img
                                src={Number03}
                                alt="number03"
                                width="40"
                                height="40"
                                className="service__img"
                            />
                            <p className="service__title">Интернет-магазин</p>
                        </div>
                        <div className="service__details">
                            <span className="service__price price3">
                                от 300000 тенге
                            </span>
                            <button className="services__btn2 btn2">
                                Подробнее
                            </button>
                        </div>
                    </div>
                    <div>
                        <span className="service__description">
                            Классический сайт, навигация по которому осуществляется с помощью меню
                        </span>
                    </div>
                </ListGroup.Item>
                <ListGroup.Item className="bootstr__item5">
                    <div className="item__service4">
                        <div className="item item4">
                            <img
                                src={Number04}
                                alt="number01"
                                width="40"
                                height="40"
                                className="service__img"
                            />
                            <p className="service__title">
                                Дополнительные услуги
                            </p>
                        </div>
                        <div>
                            <button className="services__btn2 btn5">
                                Обсудить
                            </button>
                        </div>
                    </div>
                    <div>
                        <span className="service__about">
                            Дизайн баннеров, продвижение сайтов и многое другое.
                            Цена обговаривается индивидуально
                        </span>
                    </div>
                </ListGroup.Item>
            </ListGroup>
        </div>
    );
};

export default ListServices;
