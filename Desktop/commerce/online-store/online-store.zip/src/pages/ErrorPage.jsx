import React from 'react'
import error404 from '../assets/eror404.jpg'

const ErrorPage = () => {
  return (
    <div>
        <img src={error404} alt="" />
    </div>
  )
}

export default ErrorPage