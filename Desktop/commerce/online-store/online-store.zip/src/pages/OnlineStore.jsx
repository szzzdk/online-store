import React from 'react'

const OnlineStore = () => {
  return (
    <div>онлайн магазин</div>
  )
}

export default OnlineStore