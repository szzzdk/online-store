import React from 'react'

const MultiPage = () => {
  return (
    <div>многостраничник</div>
  )
}

export default MultiPage