import React from 'react'

const Landing = () => {
  return (
    <div>лендинг</div>
  )
}

export default Landing;